import java.util.Scanner;
public class StringOperations {   
	public String add(String st){
		return (st+st);
	}
	public String replaceOdd(String st){
		String result="";
		char stArray[]=st.toCharArray();
		for(int a=0;a<st.length();a++){
			if(a%2==0){
				result+=""+'#';
			}
			else{
				result+=""+st.charAt(a);
			}
		}
		return result;
	}
	public String duplicate(String st){ 
		String result = "";
		for (int i = 0; i < st.length(); i++) {
			if(!result.contains(String.valueOf(st.charAt(i)))) {
				result += String.valueOf(st.charAt(i));
			}
		}
		return result;
	}
	public String upperCase(String st){
		String str = "";
		for (int i = 0; i <st.length(); i++) {
			if(i%2 == 0){
				str += Character.toUpperCase(st.toCharArray()[i]);
			}
			else{
				str += Character.toLowerCase(st.toCharArray()[i]);
			}
		}
		return str;
	}
	public static void main(String[] args){
		StringOperations sO=new StringOperations();
		Scanner s=new Scanner(System.in);
		System.out.println("Enter a String:");
		String st=s.next();
		System.out.println("Press:\n1.To Add String to itself\n2.Replace Odd Position with #\n"
				+ "3.Remove Duplicate Elements from String\n4.Change Odd Characters to Upper case");
		int i=s.nextInt();
		if(i==1){
			System.out.println("Added String:"+sO.add(st));
		}
		else if(i==2){
			System.out.println("Replaced String:"+sO.replaceOdd(st));
		}
		else if(i==3){
			System.out.println("Duplicate Removed String:"+sO.duplicate(st));
		}
		else if(i==4){
			System.out.println("Upper Case String:"+sO.upperCase(st));
		}
		else{
			System.out.println("Enter Correct Number");
		}   
	}
}
