import java.time.LocalDate;
import java.time.Period;
public class DateTime {
	public static void main(String[] args) {
		LocalDate pDate=LocalDate.of(1997,02,01);
		LocalDate now=LocalDate.now();
		Period diff=Period.between(pDate,now);
		System.out.printf("\n Difference  is %d years,%d months, %d days old \n \n",diff.getYears(),diff.getMonths(),diff.getDays());
	}
}