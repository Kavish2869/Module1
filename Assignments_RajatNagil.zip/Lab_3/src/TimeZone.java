import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
public class TimeZone{
	public static void main(String args[]){
		ZoneId zone1=ZoneId.of("America/New_York");
		ZoneId zone2=ZoneId.of("Europe/London");
		ZoneId zone3=ZoneId.of("Australia/Sydney");
		LocalDate dateNow1=LocalDate.now(zone1);
		LocalDate dateNow2=LocalDate.now(zone2);
		LocalDate dateNow3=LocalDate.now(zone3);
		LocalTime timeNow1=LocalTime.now(zone1);	
		LocalTime timeNow2=LocalTime.now(zone2);
		LocalTime timeNow3=LocalTime.now(zone3);
		System.out.println("America/New_York<-->"+dateNow1+"<-->"+timeNow1);
		System.out.println("Europe/London<-->"+dateNow2+"<-->"+timeNow2);
		System.out.println("Australia/Sydney<-->"+dateNow3+"<-->"+timeNow3);

	}
}