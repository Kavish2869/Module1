import java.time.LocalDate;
import java.time.Month;
import java.util.Scanner;
public class WarrantyCheck {
	public static void warranty(LocalDate date, int years,int months) {
		date=date.plusYears(years);
		date=date.plusMonths(months);
		System.out.println("Warranty Will Expire on: "+date);
	}
	public static void main(String[] args) {
		LocalDate date=LocalDate.of(2019, Month.JANUARY,29);
		System.out.println("Purchase date:"+date);
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Years of Warranty:");
		int years=sc.nextInt();
		System.out.println("Enter Months of Warranty:");
		int months=sc.nextInt();
		warranty(date,years,months);
	}
}