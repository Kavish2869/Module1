public class PersonMain {
	public static void main(String[] args) 
	{
		PersonwithEnum obj1 = new PersonwithEnum();
		obj1.setFirstName("Rajat");
		obj1.setLastName("Nagil");
		obj1.setGender(Gender.M);
		System.out.println("Person Details.....\n_____________");
		System.out.println("First Name: "+obj1.getFirstName());
		System.out.println("Last Name: "+obj1.getLastName());
		System.out.println("Gender: "+obj1.getGender());

		PersonwithEnum obj2 = new PersonwithEnum();
		obj2.setFirstName("Ekta");
		obj2.setLastName("Sharma");
		obj2.setGender(Gender.F);
		obj2.setPhonenumber("9876543210");
		System.out.println("Person Details.....\n_____________");
		System.out.println("First Name: "+obj2.getFirstName());
		System.out.println("Last Name: "+obj2.getLastName());
		System.out.println("Gender: "+obj2.getGender());
		System.out.println("Phonenumber:" + obj2.getPhonenumber());
	}
}