import java.util.Scanner;
public class StringFormattingUsingLambdaImpl {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Please Enter the String :");
		String s=sc.nextLine();
		StringFormattingUsingLambda res=(str)->{
			String s1=" ";
			for(int i=0;i<str.length();i++)
				s1 +=str.charAt(i) + " ";
			return s1;
		};
		System.out.println("The Formatted String is :"+res.formatString(s));
	}
}
