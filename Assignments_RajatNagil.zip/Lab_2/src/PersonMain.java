import java.util.Scanner;
public class PersonMain {
	public static void main(String[] args) {
		PersonClass emp1=new PersonClass();
		System.out.println("\nPerson Details:\n"+"---------\n"+emp1.dispDetails()+"\n"+"Phone NO-");
		PersonClass emp2=new PersonClass("Rajat","Nagil",Gender.M);
		System.out.println("\nPerson Details:\n"+"---------\n"+emp2.dispDetails()+"\n"+"Phone NO-"+emp2.PhoneNo(9999376856l));
	}
}
