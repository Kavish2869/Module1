public interface StringFormattingUsingLambda {
	String formatString(String s);
}
