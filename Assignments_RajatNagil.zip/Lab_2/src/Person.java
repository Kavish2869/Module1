public class Person {
	String fName;
	String lName;
	char gender;
	int age;
	float weight;	
	public void dispDetails(String fName,String lName,char gender,int age,float weight){
		System.out.println("First Name:"+fName);
		System.out.println("Last  Name:"+lName);
		System.out.println("Gender:"+gender);
		System.out.println("Age:"+age);
		System.out.println("Weight:"+weight);
	}
	public static void main(String[] args){
		System.out.println("Person Details:");
		System.out.println("--------------");
		Person per=new Person();
		per.dispDetails("Divya","Bharathi",'F',20,85.55F);
	}
}
