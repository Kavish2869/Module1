public interface PowerFunctionUsingLambda {
	double calculatePower(double x,double y);
}
