import java.util.Scanner;
public class CheckPosNeg {
	public static void main(String[] args) {
		int n;
		System.out.println("Enter the Number to check:");
		Scanner s=new Scanner(System.in);
		n=s.nextInt();
		if(n>0){
			System.out.println("Positive Number");
		}
		else if(n<0){
			System.out.println("Negative Number");
		}
		else{
			System.out.println("Zero is neither Positive nor Negative");
		}
	} 
}
