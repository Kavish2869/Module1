public class FactorialUsingLambdaMain {
	public static void main(String[] args) {
		FactorialUsingLambda f=(n)->{
			int fact=1;
			for(int i=2; i<=n;i++)
				fact *=i;
			return fact;
		};
		System.out.println("Factorial of 1 = "+f.calcFactorial(1));
		System.out.println("Factorial of 5 = "+f.calcFactorial(5));
		System.out.println("Factorial of 6 = "+f.calcFactorial(6));
		System.out.println("Factorial of 7 = "+f.calcFactorial(7));
	}
}
