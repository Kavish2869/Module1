import java.util.Scanner;
public class StringPos {   
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter String:");
		String str=sc.next();
		char[] stringToChar=str.toCharArray();
		int l=stringToChar.length;	
		int flag=1;
		for(int i=0;i<l-1;i++){
			if(stringToChar[i]<=stringToChar[i+1]){
				flag=1;
				continue;
			}
			else{
				flag=0;
				break;
			}
		}
		if(flag==1){
			System.out.println(str + "  is a Positive String");
		}
		else{
			System.out.println(str+ "   is a Negative String");
		}
	}
}
