import java.util.Scanner;
import java.util.Arrays;
public class StringArrayObjSort{
	final static int ARRAY_ELEMENTS = 3; 
	public static void main(String[] args){  
		String[] theNames = new String[5];
		Scanner keyboard = new Scanner(System.in);
		System.out.println("Enter the names: ");
		for (int i=0;i<theNames.length ;i++ ){           
			theNames[i] = keyboard.nextLine();
		} 
		System.out.println("**********************");
		Arrays.sort(theNames);
		System.out.println("Sorted Names: \n");
		System.out.print("RESULT:[");
		for (int i=0;i<((theNames.length/2)+1);i++ ){
			System.out.print(" "+theNames[i].toUpperCase());
		}
		for (int j=((theNames.length/2)+1);j<theNames.length;j++ ){
			System.out.print(" "+theNames[j]);
		}
		System.out.print("]");
	} 
}