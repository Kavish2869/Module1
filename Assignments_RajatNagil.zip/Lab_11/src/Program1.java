interface FuncInterface { 
	void abstractFun(double x,double y);
	default void normalFun() { 
		System.out.println("Hii"); 
	} 
} 
class Program1{ 
	public static void main(String args[]) { 
		FuncInterface fobj = (double x,double y)->System.out.println(Math.pow(x, y)); 
		fobj.abstractFun(5,6); 
	} 
}